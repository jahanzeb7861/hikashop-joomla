<?php
/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   (C) 2013 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
// TODO CHANGE HERE
//  echo $displayData['id']; 
//  echo $displayData['id']; 
?>
<div class="btn-toolbar" style="display: flex;" role="toolbar" aria-label="<?php echo JText::_('JTOOLBAR'); ?>"
    id="<?php echo $displayData['id']; ?>">

    <button class="btn btn-small button-apply btn-success" style="order: 1;" data-bs-toggle="modal"
        data-bs-target="#exampleModal">
        Ship</button>

    <button class="btn btn-small button-apply btn-info" style="order: 1;">
        Refund Label</button>

    <button class="btn btn-small button-apply btn-secondary" style="order: 1;">
        End of Day</button>

        <script>
            // alert('TEST');
        </script>



